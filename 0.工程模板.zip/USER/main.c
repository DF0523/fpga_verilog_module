#include "stm32f10x.h"
#include "led.h"
#include "key_test.h"
#include "mydefine.h"

void Delay(u32 i)
{
	u32 m;
	u8 n;
	for(m=0;m<=i*(110);m++)
		for(n=0;n<=111;n++);
}


 int main(void)
 {	 
	LED_Init();
	KEY_Init();

  while(1)
	{

		if(readPA0)
		{
			Delay(20);
			if(readPA0)
			{
					GPIO_ResetBits(GPIOD,GPIO_Pin_3);//��
					while(readPA0);
			}
		}
		
		
		if(readPF11)
		{
			Delay(20);
			if(readPF11)
			{
					GPIO_SetBits(GPIOD,GPIO_Pin_3);//��
					while(readPF11);
			
		  }
	  }
	}
 }

 
 
 
 
 
 
 
 
 
 
 
